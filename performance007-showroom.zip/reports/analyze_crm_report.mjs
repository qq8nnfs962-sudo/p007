import fs from 'fs';

const inputPath = '/home/ubuntu/performance007-showroom/reports/current_crm_analytics.json';
const outputPath = '/home/ubuntu/performance007-showroom/reports/crm_analysis_summary.json';
const payload = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
const analytics = payload.analytics;
const leads = analytics.recentLeads;

const byPriority = Object.fromEntries(['Vysoká', 'Stredná', 'Nízka'].map((priority) => [priority, leads.filter((lead) => lead.priority === priority).length]));
const byVehicle = leads.reduce((acc, lead) => {
  acc[lead.vehicle] = (acc[lead.vehicle] ?? 0) + 1;
  return acc;
}, {});
const duplicateGroups = Object.entries(leads.reduce((acc, lead) => {
  const key = `${lead.email}|${lead.vehicle}`;
  acc[key] = acc[key] || [];
  acc[key].push(lead.id);
  return acc;
}, {})).filter(([, ids]) => ids.length > 1).map(([key, ids]) => {
  const [email, vehicle] = key.split('|');
  return { email, vehicle, count: ids.length, ids };
});
const highValueLeads = leads.filter((lead) => lead.estimatedValue >= 200000).map((lead) => ({ name: lead.name, email: lead.email, vehicle: lead.vehicle, estimatedValue: lead.estimatedValue, priority: lead.priority }));
const topVehicles = Object.entries(byVehicle).sort((a, b) => b[1] - a[1]).map(([vehicle, count]) => ({ vehicle, count }));
const dataQualityNotes = [];
if (duplicateGroups.length) dataQualityNotes.push('Multiple entries share the same email and vehicle, indicating test submissions or duplicate lead captures that should be deduplicated before sales forecasting.');
if (analytics.stageDistribution.filter((stage) => stage.count > 0).length === 1 && analytics.stageDistribution[0]?.stage === 'Nový lead') dataQualityNotes.push('All current leads are still in the New Lead stage, so pipeline progress metrics are not yet representative of active deal movement.');
if (analytics.sourceDistribution.length === 1) dataQualityNotes.push('All leads currently originate from the contact form, so source attribution is not diversified yet.');

const summary = {
  generatedAt: analytics.generatedAt,
  totalLeads: analytics.totalLeads,
  pipelineValue: analytics.pipelineValue,
  averageDealValue: analytics.averageDealValue,
  highPriorityLeads: analytics.highPriorityLeads,
  financingRequests: analytics.financingRequests,
  byPriority,
  topVehicles,
  duplicateGroups,
  highValueLeads,
  dataQualityNotes,
  recommendedActions: [
    'Deduplicate repeated test/contact-form leads before using pipeline value for management decisions.',
    'Move qualified high-value Porsche and Mercedes-AMG leads into follow-up stages with assigned owners and deadlines.',
    'Add CRM fields for status, owner, phone, source campaign, and next follow-up date to improve pipeline accuracy.',
    'Track financing intent explicitly instead of inferring it only from free-text messages.'
  ]
};
fs.writeFileSync(outputPath, JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary, null, 2));
