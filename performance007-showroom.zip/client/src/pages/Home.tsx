/*
Neo-Noir Tactical Modernism for performance007.sk.
This page must reinforce a classified automotive briefing mood: dark layered surfaces, low-left cinematic copy, carbon-fiber / brushed-metal CSS textures, restrained HUD linework, sovereign-gold micro accents, and agent-red decisive CTAs.
*/

import { useMemo, useState } from "react";
import { ChevronDown, Gauge, Heart, Menu, Radar, Search, ShieldCheck, SlidersHorizontal, Zap } from "lucide-react";

const ASSETS = {
  hero: "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_hero-9FHBya7qxNt3TNUM4LCTP9.webp",
  inventory: "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_inventory-LNUdMRJL4y5mZKqG77NZrU.webp",
  dossier: "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_dossier-Shd4SnibbAChXUZudgWwn8.webp",
  garage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_garage-4eDmDrJeFFfp8kZGhBKz2J.webp",
  finance: "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_finance-nW7RXVDy6F9aTby9HxXH8t.webp",
};

type Vehicle = {
  id: string;
  year: number;
  make: string;
  model: string;
  price: number;
  hp: number;
  drivetrain: "AWD" | "RWD" | "4MATIC" | "xDrive";
  zeroToHundred: number;
  mileage: number;
  image: string;
  tags: string[];
  dossier: string;
};

type EnquiryForm = {
  name: string;
  email: string;
  vehicle: string;
  message: string;
};

type SubmissionStatus = "idle" | "loading" | "success" | "error";

const vehicles: Vehicle[] = [
  {
    id: "p007-db12-shadow",
    year: 2025,
    make: "Aston Martin",
    model: "DB12 Shadow Protocol",
    price: 137000,
    hp: 680,
    drivetrain: "RWD",
    zeroToHundred: 3.6,
    mileage: 1400,
    image: ASSETS.hero,
    tags: ["Karbónový balík", "Keramické brzdy", "Zberateľský stav"],
    dossier: "Luxusné cestovné vozidlo s karbónovými doplnkami a decentným interiérom.",
  },
  {
    id: "p007-m4-obsidian",
    year: 2024,
    make: "BMW",
    model: "M4 CSL Obsidian",
    price: 158000,
    hp: 550,
    drivetrain: "RWD",
    zeroToHundred: 3.7,
    mileage: 6200,
    image: ASSETS.inventory,
    tags: ["Okruhové nastavenie", "Kované disky", "Laserové LED"],
    dossier: "Ľahké kupé rýchlej reakcie naladené na presné trasy, horské prejazdy a víkendové okruhové operácie.",
  },
  {
    id: "p007-gt63-radar",
    year: 2025,
    make: "Mercedes-AMG",
    model: "GT 63 Radar Edition",
    price: 219000,
    hp: 639,
    drivetrain: "4MATIC",
    zeroToHundred: 3.2,
    mileage: 2500,
    image: ASSETS.dossier,
    tags: ["Manažérska strela", "Nočný paket", "Burmester"],
    dossier: "Diskrétna manažérska strela s trakciou do každého počasia, kultivovanosťou na dlhé trasy a okamžitou akceleračnou autoritou.",
  },
  {
    id: "p007-911-steel",
    year: 2023,
    make: "Porsche",
    model: "911 Turbo S Steel Line",
    price: 242000,
    hp: 650,
    drivetrain: "AWD",
    zeroToHundred: 2.7,
    mileage: 4800,
    image: ASSETS.garage,
    tags: ["Sport Chrono", "PCCB", "Zdvih prednej nápravy"],
    dossier: "Kompaktný presný nástroj s drvivým štartom a každodennou použiteľnosťou na diskrétne vysokorýchlostné presuny.",
  },
];

const schema = {
  "@context": "https://schema.org",
  "@type": "AutoDealer",
  name: "performance007.sk",
  url: "https://performance007.sk",
  description: "Prémiový takticko-luxusný salón výkonných vozidiel s kurátorovanou ponukou, technickými zložkami, financovaním a bezpečnou komunikáciou s klientmi.",
  makesOffer: vehicles.map((vehicle) => ({
    "@type": "Offer",
    priceCurrency: "EUR",
    price: vehicle.price,
    itemOffered: {
      "@type": "Car",
      name: `${vehicle.year} ${vehicle.make} ${vehicle.model}`,
      vehicleConfiguration: vehicle.drivetrain,
      mileageFromOdometer: {
        "@type": "QuantitativeValue",
        value: vehicle.mileage,
        unitCode: "KMT",
      },
    },
  })),
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("sk-SK", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value);
}

function monthlyPayment(price: number, down: number, annualRate: number, months: number) {
  const principal = Math.max(price - down, 0);
  const monthlyRate = annualRate / 100 / 12;
  if (monthlyRate === 0) return principal / months;
  return (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -months));
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="stat-tile">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function SectionKicker({ children }: { children: React.ReactNode }) {
  return <p className="section-kicker">{children}</p>;
}

export default function Home() {
  const [hpFloor, setHpFloor] = useState(550);
  const [drivetrain, setDrivetrain] = useState("ALL");
  const [acceleration, setAcceleration] = useState(3.8);
  const [selectedId, setSelectedId] = useState(vehicles[0].id);
  const [favorites, setFavorites] = useState<string[]>([vehicles[0].id]);
  const [vehiclePrice, setVehiclePrice] = useState(77000);
  const [downPayment, setDownPayment] = useState(7000);
  const [rate, setRate] = useState(1.8371);
  const [months, setMonths] = useState(120);
  const [enquiryForm, setEnquiryForm] = useState<EnquiryForm>({ name: "", email: "", vehicle: "", message: "" });
  const [submissionStatus, setSubmissionStatus] = useState<SubmissionStatus>("idle");
  const [submissionMessage, setSubmissionMessage] = useState("");

  const filteredVehicles = useMemo(
    () =>
      vehicles.filter((vehicle) => {
        const drivetrainMatch = drivetrain === "ALL" || vehicle.drivetrain === drivetrain;
        return vehicle.hp >= hpFloor && drivetrainMatch && vehicle.zeroToHundred <= acceleration;
      }),
    [hpFloor, drivetrain, acceleration],
  );

  const selectedVehicle = vehicles.find((vehicle) => vehicle.id === selectedId) ?? vehicles[0];
  const payment = monthlyPayment(vehiclePrice, downPayment, rate, months);

  const toggleFavorite = (id: string) => {
    setFavorites((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  };

  const updateEnquiryField = (field: keyof EnquiryForm, value: string) => {
    setEnquiryForm((current) => ({ ...current, [field]: value }));
  };

  const submitEnquiry = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmissionStatus("loading");
    setSubmissionMessage("Ukladám Vašu požiadavku do databázy…");

    try {
      const response = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(enquiryForm),
      });
      const payload = await response.json().catch(() => ({}));

      if (!response.ok || !payload.success) {
        throw new Error(payload.error || "Požiadavku sa nepodarilo uložiť.");
      }

      setSubmissionStatus("success");
      setSubmissionMessage("Vaša požiadavka bola uložená. Ozveme sa Vám cez preferovaný kanál.");
      setEnquiryForm({ name: "", email: "", vehicle: "", message: "" });
    } catch (error) {
      setSubmissionStatus("error");
      setSubmissionMessage(error instanceof Error ? error.message : "Požiadavku sa nepodarilo uložiť.");
    }
  };

  return (
    <div className="site-shell bg-background text-foreground">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />

      <header className="fixed left-0 right-0 top-0 z-50 flex items-center justify-between px-5 py-5 text-steel md:px-9">
        <a href="#top" className="nav-control" aria-label="Otvoriť menu">
          <Menu size={24} />
          <span>Menu</span>
        </a>
        <a href="#top" className="brand-mark" aria-label="Domov performance007.sk">
          <span>performance</span><strong>007</strong><small>.sk</small>
        </a>
        <div className="flex items-center gap-4">
          <a className="currency-control" href="/dashboard">CRM</a>
          <a className="currency-control" href="#inventory">EUR <ChevronDown size={13} /></a>
          <a className="search-orbit" href="#inventory" aria-label="Hľadať v ponuke"><Search size={22} /></a>
        </div>
      </header>

      <main id="top">
        <section className="hero-panel min-h-screen" style={{ backgroundImage: `url(${ASSETS.hero})` }}>
          <div className="hero-overlay" style={{height: '527px'}} />
          <div className="gunbarrel-ring" aria-hidden="true" />
          <div className="hero-copy">
            <SectionKicker>špecializujeme sa na predaj, dovoz a výkup vozidiel</SectionKicker>
            <h1 style={{ fontSize: "72px" }}>PERFORMANCE 007</h1>
            <p></p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a className="btn-agent" href="#inventory">Naša PONUKA</a>
              <a className="btn-ghost" href="#dossier">Otvoriť zložku</a>
            </div>
          </div>
          <div className="hero-index"><span>01</span><i /> <span>Misijný salón</span></div>
          <div className="outline-007" aria-hidden="true">007</div>
        </section>

        <section className="full-image-panel" style={{ backgroundImage: `url(${ASSETS.inventory})` }}>
          <div className="image-panel-shade" />
          <div className="panel-copy wide-copy">
            <SectionKicker>Máte vlastnú predstavu o vašom budúcom vozidle?</SectionKicker>
            <h2>VOZIDLÁ NA OBJEDNÁVKU</h2>
            <p>Import, konfigurácia, detailná príprava a diskrétne odovzdanie pre klientov, ktorí odmietajú kompromis.</p>
            <a href="#contact" className="btn-light">Zadajte požiadavku a Splňte si svoj sen</a>
          </div>
        </section>

        <section id="inventory" className="inventory-section tactical-surface">
          <div className="container py-20 md:py-28">
            <div className="section-head asymmetric-head">
              <div>
                <SectionKicker>Prieskumná platforma vozidiel</SectionKicker>
                <h2>Vyhľadávací modul ponuky</h2>
              </div>
              <p>Filtrujte aktívnu flotilu podľa výkonu, pohonu a schopnosti zrýchlenia. Obľúbené vozidlá sa ukladajú lokálne pre aktuálnu poradovú reláciu.</p>
            </div>

            <div className="filter-console">
              <div className="filter-title"><SlidersHorizontal size={18} /> Pokročilé taktické filtre</div>
              <label>Minimálny výkon <strong>{hpFloor} HP</strong><input type="range" min="500" max="700" step="10" value={hpFloor} onChange={(event) => setHpFloor(Number(event.target.value))} /></label>
              <label>Limit 0-100 km/h <strong>{acceleration.toFixed(1)} s</strong><input type="range" min="2.6" max="4.2" step="0.1" value={acceleration} onChange={(event) => setAcceleration(Number(event.target.value))} /></label>
              <label>Pohon <select value={drivetrain} onChange={(event) => setDrivetrain(event.target.value)}><option value="ALL">Všetky systémy</option><option value="RWD">RWD</option><option value="AWD">AWD</option><option value="4MATIC">4MATIC</option><option value="xDrive">xDrive</option></select></label>
            </div>

            <div className="vehicle-grid">
              {filteredVehicles.map((vehicle) => (
                <article key={vehicle.id} className="vehicle-card">
                  <button className={`favorite ${favorites.includes(vehicle.id) ? "active" : ""}`} onClick={() => toggleFavorite(vehicle.id)} aria-label="Prepnúť obľúbené vozidlo"><Heart size={18} fill="currentColor" /></button>
                  <img src={vehicle.image} alt={`${vehicle.make} ${vehicle.model}`} loading="lazy" />
                  <div className="vehicle-card-body">
                    <p>{vehicle.year} / {vehicle.drivetrain} / {vehicle.mileage.toLocaleString("sk-SK")} km</p>
                    <h3>{vehicle.make}<span>{vehicle.model}</span></h3>
                    <div className="vehicle-stats"><Stat label="Výkon" value={`${vehicle.hp} HP`} /><Stat label="0-100" value={`${vehicle.zeroToHundred}s`} /><Stat label="Cena" value={formatCurrency(vehicle.price)} /></div>
                    <div className="tag-row">{vehicle.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                    <button className="btn-card" onClick={() => { setSelectedId(vehicle.id); setVehiclePrice(vehicle.price); document.getElementById("dossier")?.scrollIntoView({ behavior: "smooth" }); }}>Otvoriť technickú zložku</button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="dossier" className="dossier-section" style={{ backgroundImage: `url(${ASSETS.dossier})` }}>
          <div className="dossier-shade" />
          <div className="container dossier-grid py-20 md:py-28">
            <div className="dossier-visual">
              <SectionKicker>Detaily vozidla</SectionKicker>
              <h2>Technická zložka</h2>
              <p>{selectedVehicle.dossier}</p>
              <div className="scan-module"><Radar /><span>360° virtuálny sken</span><strong>Simulovaný orbit aktívny</strong></div>
            </div>
            <aside className="spec-ledger">
              <div className="ledger-header"><span>ID spisu {selectedVehicle.id}</span><ShieldCheck size={18} /></div>
              <h3>{selectedVehicle.year} {selectedVehicle.make}<br />{selectedVehicle.model}</h3>
              <dl>
                <div><dt>Cena</dt><dd>{formatCurrency(selectedVehicle.price)}</dd></div>
                <div><dt>Výkon</dt><dd>{selectedVehicle.hp} HP</dd></div>
                <div><dt>Pohon</dt><dd>{selectedVehicle.drivetrain}</dd></div>
                <div><dt>0-100 km/h</dt><dd>{selectedVehicle.zeroToHundred}s</dd></div>
                <div><dt>Nájazd</dt><dd>{selectedVehicle.mileage.toLocaleString("sk-SK")} km</dd></div>
              </dl>
              <a className="btn-agent w-full justify-center" href="#contact">Požiadať o poradenstvo</a>
            </aside>
          </div>
        </section>

        <section className="garage-section" style={{ backgroundImage: `url(${ASSETS.garage})` }}>
          <div className="image-panel-shade" />
          <div className="container garage-layout py-24 md:py-32">
            <div>
              <SectionKicker>Integrácia prémiovej garáže</SectionKicker>
              <h2>Karbónová presnosť. Oceľová dôvera. Ticho, v ktorom začína tvoja jazda.</h2>
              <p>Odovzdanie ako privátne odhalenie: detailná kontrola, keramická ochrana a pripravené riešenie uskladnenia pre vozidlá, ktoré majú hodnotu.</p>
            </div>
            <div className="garage-cards">
              <div><Zap /><strong>LED inšpekčné polia</strong><span>Precízne osvetlenie pre dokonalú kontrolu laku, karbónu a každého detailu vozidla.</span></div>
              <div><Gauge /><strong>Výkonnostná príprava</strong><span>Kompletná validácia pred odovzdaním – test jazdy, kontrola systémov a pripravenosť bez kompromisov.</span></div>
              <div><ShieldCheck /><strong>Diskrétne uskladnenie</strong><span>Privátne boxy s kontrolovanou klímou, zabezpečením a starostlivosťou pre vozidlá s hodnotou.</span></div>
            </div>
          </div>
        </section>

        <section id="finance" className="finance-section" style={{ backgroundImage: `url(${ASSETS.finance})` }}>
          <div className="finance-shade" />
          <div className="container finance-grid py-20 md:py-28">
            <div>
              <SectionKicker>Financovanie Q-Branch</SectionKicker>
              <h2>Vypočítajte rozpočet operácie.</h2>
              <p>Namodelujte si orientačnú mesačnú splátku pred vyžiadaním súkromnej ponuky. Hodnoty sú ilustračné a mal by ich potvrdiť špecialista financovania.</p>
            </div>
            <div className="finance-console">
              <label>Cena vozidla <strong>{formatCurrency(vehiclePrice)}</strong><input type="range" min="50000" max="320000" step="1000" value={vehiclePrice} onChange={(event) => setVehiclePrice(Number(event.target.value))} /></label>
              <label>Akontácia <strong>{formatCurrency(downPayment)}</strong><input type="range" min="0" max="120000" step="1000" value={downPayment} onChange={(event) => setDownPayment(Number(event.target.value))} /></label>
              <label>Úrok <strong>{rate.toFixed(1)}%</strong><input type="range" min="0" max="9" step="0.1" value={rate} onChange={(event) => setRate(Number(event.target.value))} /></label>
              <label>Doba splácania <strong>{months} mesiacov</strong><input type="range" min="24" max="180" step="12" value={months} onChange={(event) => setMonths(Number(event.target.value))} /></label>
              <div className="payment-readout"><span>Odhad mesačne</span><strong>{formatCurrency(payment)}</strong></div>
            </div>
          </div>
        </section>

        <section id="contact" className="contact-section tactical-surface">
          <div className="container contact-grid py-20 md:py-28">
            <div>
              <SectionKicker>Férová komunikácia</SectionKicker>
              <h2>Bezplatné poradenstvo</h2>
              <p>Pošlite Vašu požiadavku na akvizíciu, možnosti financovania, či inú technickú požiadavku do našej garáže. Špecialista Vám obratom odpovie cez preferovaný bezpečný kanál.</p>
              <div className="contact-meta"><span>Showroom: Košice - okolie / Hýľov </span><span>Signál: +421 905 143 257</span><span>kontaktný formulár </span></div>
            </div>
            <form className="secure-form" onSubmit={submitEnquiry}>
              <input placeholder="Meno klienta" aria-label="Meno" value={enquiryForm.name} onChange={(event) => updateEnquiryField("name", event.target.value)} required minLength={2} />
              <input placeholder="Bezpečný e-mail" aria-label="E-mail" type="email" value={enquiryForm.email} onChange={(event) => updateEnquiryField("email", event.target.value)} required />
              <input placeholder="Cieľové vozidlo alebo typ misie" aria-label="Vozidlo" value={enquiryForm.vehicle} onChange={(event) => updateEnquiryField("vehicle", event.target.value)} required minLength={2} />
              <textarea placeholder="Poznámky k porade" aria-label="Správa" rows={5} value={enquiryForm.message} onChange={(event) => updateEnquiryField("message", event.target.value)} required minLength={5} />
              {submissionMessage && <p className={`form-status ${submissionStatus}`}>{submissionMessage}</p>}
              <button className="btn-agent" type="submit" disabled={submissionStatus === "loading"}>{submissionStatus === "loading" ? "Ukladám požiadavku…" : "Odoslať požiadavku"}</button>
            </form>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span>performance007.sk</span>
        <p>Prémiové automobilové služby, financovanie a integrácia.</p>
        <a href="#top">Späť hore</a>
      </footer>
    </div>
  );
}
