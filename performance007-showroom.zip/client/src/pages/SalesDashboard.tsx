import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, BarChart3, CircleDollarSign, Gauge, RefreshCcw, TrendingUp, Users } from "lucide-react";

type CRMLead = {
  id: number;
  name: string;
  email: string;
  vehicle: string;
  message: string;
  source: string;
  createdAt: string;
  stage: "Nový lead" | "Kvalifikácia" | "Ponuka" | "Financovanie";
  estimatedValue: number;
  priority: "Vysoká" | "Stredná" | "Nízka";
  nextAction: string;
};

type CRMAnalytics = {
  generatedAt: string;
  totalLeads: number;
  pipelineValue: number;
  averageDealValue: number;
  financingRequests: number;
  highPriorityLeads: number;
  sourceDistribution: Array<{ source: string; count: number }>;
  stageDistribution: Array<{ stage: CRMLead["stage"]; count: number; value: number }>;
  recentLeads: CRMLead[];
};

type APIResponse = { success: true; analytics: CRMAnalytics } | { success: false; error: string };

const emptyAnalytics: CRMAnalytics = {
  generatedAt: new Date().toISOString(),
  totalLeads: 0,
  pipelineValue: 0,
  averageDealValue: 0,
  financingRequests: 0,
  highPriorityLeads: 0,
  sourceDistribution: [],
  stageDistribution: [
    { stage: "Nový lead", count: 0, value: 0 },
    { stage: "Kvalifikácia", count: 0, value: 0 },
    { stage: "Ponuka", count: 0, value: 0 },
    { stage: "Financovanie", count: 0, value: 0 },
  ],
  recentLeads: [],
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("sk-SK", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value);
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("sk-SK", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function MetricCard({ icon: Icon, label, value, hint }: { icon: typeof Users; label: string; value: string; hint: string }) {
  return (
    <article className="dashboard-metric">
      <div className="metric-icon"><Icon size={21} /></div>
      <span>{label}</span>
      <strong>{value}</strong>
      <p>{hint}</p>
    </article>
  );
}

export default function SalesDashboard() {
  const [analytics, setAnalytics] = useState<CRMAnalytics>(emptyAnalytics);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [message, setMessage] = useState("Načítavam CRM analytiku…");

  const loadAnalytics = async () => {
    setStatus("loading");
    setMessage("Načítavam CRM analytiku…");

    try {
      const response = await fetch("/api/crm/analytics");
      const payload = (await response.json()) as APIResponse;

      if (!response.ok || !payload.success) {
        throw new Error(payload.success ? "CRM analytiku sa nepodarilo načítať." : payload.error);
      }

      setAnalytics(payload.analytics);
      setStatus("ready");
      setMessage("CRM dáta sú synchronizované z databázy požiadaviek.");
    } catch (error) {
      setAnalytics(emptyAnalytics);
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "CRM analytiku sa nepodarilo načítať.");
    }
  };

  useEffect(() => {
    void loadAnalytics();
  }, []);

  const maxStageValue = useMemo(() => Math.max(...analytics.stageDistribution.map((stage) => stage.value), 1), [analytics.stageDistribution]);

  return (
    <div className="dashboard-shell">
      <aside className="dashboard-sidebar">
        <a href="/" className="dashboard-back"><ArrowLeft size={18} /> Späť na web</a>
        <div className="dashboard-brand"><span>performance</span><strong>007</strong><small>.crm</small></div>
        <nav>
          <a href="#overview">Prehľad</a>
          <a href="#pipeline">Pipeline</a>
          <a href="#leads">Leady</a>
        </nav>
      </aside>

      <main className="dashboard-main" id="overview">
        <header className="dashboard-hero">
          <div>
            <p className="section-kicker">Interný sales cockpit</p>
            <h1>CRM analytika a predajný pipeline</h1>
            <p>Dashboard číta reálne požiadavky uložené z kontaktného formulára, transformuje ich na CRM leady a ukazuje hodnotu pipeline bez manuálneho exportu.</p>
          </div>
          <button className="btn-agent" type="button" onClick={loadAnalytics} disabled={status === "loading"}><RefreshCcw size={16} /> Obnoviť CRM</button>
        </header>

        <p className={`dashboard-status ${status}`}>{message}</p>

        <section className="dashboard-metrics-grid">
          <MetricCard icon={Users} label="Leady spolu" value={analytics.totalLeads.toString()} hint="Všetky uložené požiadavky v CRM pohľade" />
          <MetricCard icon={CircleDollarSign} label="Pipeline hodnota" value={formatCurrency(analytics.pipelineValue)} hint="Deterministický odhad podľa vozidla a zámeru" />
          <MetricCard icon={TrendingUp} label="Priemerný obchod" value={formatCurrency(analytics.averageDealValue)} hint="Priemerná kvalifikovaná hodnota leadu" />
          <MetricCard icon={Gauge} label="Financovanie" value={analytics.financingRequests.toString()} hint="Požiadavky s financovaním alebo splátkami" />
        </section>

        <section className="dashboard-grid" id="pipeline">
          <article className="dashboard-panel wide-panel">
            <div className="panel-title"><BarChart3 size={18} /> Predajný pipeline</div>
            <div className="pipeline-bars">
              {analytics.stageDistribution.map((stage) => (
                <div className="pipeline-row" key={stage.stage}>
                  <div><strong>{stage.stage}</strong><span>{stage.count} leadov · {formatCurrency(stage.value)}</span></div>
                  <div className="pipeline-track"><i style={{ width: `${Math.max(6, (stage.value / maxStageValue) * 100)}%` }} /></div>
                </div>
              ))}
            </div>
          </article>

          <article className="dashboard-panel">
            <div className="panel-title">CRM integrácia</div>
            <dl className="integration-ledger">
              <div><dt>Zdroj dát</dt><dd>Databáza enquiries</dd></div>
              <div><dt>Synchronizácia</dt><dd>{status === "ready" ? "Aktívna" : "Čaká"}</dd></div>
              <div><dt>Prioritné leady</dt><dd>{analytics.highPriorityLeads}</dd></div>
              <div><dt>Aktualizované</dt><dd>{formatDate(analytics.generatedAt)}</dd></div>
            </dl>
          </article>
        </section>

        <section className="dashboard-panel" id="leads">
          <div className="panel-title">Najnovšie CRM leady</div>
          <div className="lead-table">
            <div className="lead-row lead-head"><span>Klient</span><span>Vozidlo</span><span>Fáza</span><span>Hodnota</span><span>Ďalší krok</span></div>
            {analytics.recentLeads.length === 0 && <p className="dashboard-empty">Zatiaľ nie sú uložené žiadne požiadavky.</p>}
            {analytics.recentLeads.slice(0, 12).map((lead) => (
              <div className="lead-row" key={lead.id}>
                <span><strong>{lead.name}</strong><small>{lead.email}</small></span>
                <span>{lead.vehicle}</span>
                <span><i className={`priority-dot ${lead.priority.toLowerCase()}`} />{lead.stage}</span>
                <span>{formatCurrency(lead.estimatedValue)}</span>
                <span>{lead.nextAction}</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
