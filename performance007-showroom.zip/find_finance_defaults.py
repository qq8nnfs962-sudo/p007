price = 77000
down = 7000
principal = price - down
best = []
for months in range(24, 181):
    for rate_i in range(0, 1501):
        rate = rate_i / 100
        mr = rate / 100 / 12
        payment = principal / months if mr == 0 else (principal * mr) / (1 - (1 + mr) ** (-months))
        best.append((abs(payment - 639), months, rate, payment))
for diff, months, rate, payment in sorted(best)[:20]:
    print(f"diff={diff:.4f}, months={months}, rate={rate:.2f}, payment={payment:.2f}")
