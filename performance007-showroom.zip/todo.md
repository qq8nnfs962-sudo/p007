# Database Persistence Verification Todo

- [x] Inspect current project schema, migrations, database helpers, API routes, and frontend data flows.
- [x] Confirm existing database-backed user-generated enquiry persistence is working.
- [x] Determine whether inventory data is still static or already persisted.
- [ ] Add or restore persistent vehicle inventory storage if missing.
- [ ] Add API route(s) for reading persisted vehicle inventory if missing.
- [ ] Connect the public inventory/detail UI to database-backed data while keeping fallback resilience.
- [ ] Add or update tests for database-backed website data persistence.
- [ ] Run database migration if schema changes are needed.
- [ ] Run TypeScript, tests, production build, server restart, API smoke tests, and preview validation.
- [ ] Save a checkpoint and deliver the persistence summary.
