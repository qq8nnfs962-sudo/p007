import { chromium } from 'playwright';

const baseUrl = 'http://127.0.0.1:3000';
const browser = await chromium.launch({ headless: true, executablePath: '/usr/bin/chromium' });
const page = await browser.newPage();

try {
  await page.goto(`${baseUrl}/`, { waitUntil: 'networkidle' });
  await page.locator('input[aria-label="Meno"]').fill('UI Dashboard Test');
  await page.locator('input[aria-label="E-mail"]').fill('ui-dashboard-test@example.com');
  await page.locator('input[aria-label="Vozidlo"]').fill('Porsche 911 Turbo S');
  await page.locator('textarea[aria-label="Správa"]').fill('UI regression submission after CRM dashboard implementation.');
  await page.locator('form.secure-form button[type="submit"]').click();
  await page.locator('.form-status.success').waitFor({ timeout: 10_000 });
  const successMessage = await page.locator('.form-status.success').innerText();
  if (!successMessage.toLowerCase().includes('uložená')) {
    throw new Error(`Unexpected success message: ${successMessage}`);
  }

  await page.goto(`${baseUrl}/dashboard`, { waitUntil: 'networkidle' });
  await page.getByText('CRM dáta sú synchronizované z databázy požiadaviek.').waitFor({ timeout: 10_000 });
  await page.getByText('UI Dashboard Test').first().waitFor({ timeout: 10_000 });

  console.log(JSON.stringify({ success: true, successMessage }, null, 2));
} finally {
  await browser.close();
}
