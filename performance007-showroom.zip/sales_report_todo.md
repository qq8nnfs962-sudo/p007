# Sales Analytics Report Todo

- [x] Read the internal-sales-analytics-dashboard skill instructions.
- [x] Pull current CRM analytics from the live dashboard API.
- [x] Analyze pipeline value, lead count, lead quality, and recent activity.
- [x] Write a professional Markdown sales analytics report.
- [x] Deliver the report with the source data summary.
