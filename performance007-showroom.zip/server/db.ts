import { asc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertVehicle, users, vehicles } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export type VehicleInventoryItem = {
  id: string;
  year: number;
  make: string;
  model: string;
  price: number;
  hp: number;
  drivetrain: "AWD" | "RWD" | "4MATIC" | "xDrive";
  zeroToHundred: number;
  mileage: number;
  image: string;
  tags: string[];
  dossier: string;
};

const seedVehicles: InsertVehicle[] = [
  {
    id: "p007-db12-shadow",
    year: 2025,
    make: "Aston Martin",
    model: "DB12 Shadow Protocol",
    price: 137000,
    hp: 680,
    drivetrain: "RWD",
    zeroToHundredTenths: 36,
    mileage: 1400,
    imageUrl:
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_hero-9FHBya7qxNt3TNUM4LCTP9.webp",
    tagsJson: JSON.stringify(["Karbónový balík", "Keramické brzdy", "Zberateľský stav"]),
    dossier: "Luxusné cestovné vozidlo s karbónovými doplnkami a decentným interiérom.",
    sortOrder: 10,
  },
  {
    id: "p007-m4-obsidian",
    year: 2024,
    make: "BMW",
    model: "M4 CSL Obsidian",
    price: 158000,
    hp: 550,
    drivetrain: "RWD",
    zeroToHundredTenths: 37,
    mileage: 6200,
    imageUrl:
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_inventory-LNUdMRJL4y5mZKqG77NZrU.webp",
    tagsJson: JSON.stringify(["Okruhové nastavenie", "Kované disky", "Laserové LED"]),
    dossier: "Ľahké kupé rýchlej reakcie naladené na presné trasy, horské prejazdy a víkendové okruhové operácie.",
    sortOrder: 20,
  },
  {
    id: "p007-gt63-radar",
    year: 2025,
    make: "Mercedes-AMG",
    model: "GT 63 Radar Edition",
    price: 219000,
    hp: 639,
    drivetrain: "4MATIC",
    zeroToHundredTenths: 32,
    mileage: 2500,
    imageUrl:
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_dossier-Shd4SnibbAChXUZudgWwn8.webp",
    tagsJson: JSON.stringify(["Manažérska strela", "Nočný paket", "Burmester"]),
    dossier: "Diskrétna manažérska strela s trakciou do každého počasia, kultivovanosťou na dlhé trasy a okamžitou akceleračnou autoritou.",
    sortOrder: 30,
  },
  {
    id: "p007-911-steel",
    year: 2023,
    make: "Porsche",
    model: "911 Turbo S Steel Line",
    price: 242000,
    hp: 650,
    drivetrain: "AWD",
    zeroToHundredTenths: 27,
    mileage: 4800,
    imageUrl:
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663483823068/Qu3DnTeenN5m4JxRZ5xnpt/performance007_garage-4eDmDrJeFFfp8kZGhBKz2J.webp",
    tagsJson: JSON.stringify(["Sport Chrono", "PCCB", "Zdvih prednej nápravy"]),
    dossier: "Kompaktný presný nástroj s drvivým štartom a každodennou použiteľnosťou na diskrétne vysokorýchlostné presuny.",
    sortOrder: 40,
  },
];

export const fallbackVehicles: VehicleInventoryItem[] = seedVehicles.map(vehicleFromInsert);

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function seedVehicleInventoryIfEmpty(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot seed vehicles: database not available");
    return;
  }

  const existing = await db.select({ id: vehicles.id }).from(vehicles).limit(1);
  if (existing.length > 0) return;

  await db.insert(vehicles).values(seedVehicles);
}

export async function getVehicleInventory(): Promise<VehicleInventoryItem[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Returning fallback vehicles: database not available");
    return fallbackVehicles;
  }

  await seedVehicleInventoryIfEmpty();
  const rows = await db.select().from(vehicles).orderBy(asc(vehicles.sortOrder));

  return rows.map(vehicleFromRow);
}

function vehicleFromInsert(vehicle: InsertVehicle): VehicleInventoryItem {
  return {
    id: vehicle.id,
    year: vehicle.year,
    make: vehicle.make,
    model: vehicle.model,
    price: vehicle.price,
    hp: vehicle.hp,
    drivetrain: vehicle.drivetrain as VehicleInventoryItem["drivetrain"],
    zeroToHundred: vehicle.zeroToHundredTenths / 10,
    mileage: vehicle.mileage,
    image: vehicle.imageUrl,
    tags: parseTags(vehicle.tagsJson),
    dossier: vehicle.dossier,
  };
}

function vehicleFromRow(vehicle: typeof vehicles.$inferSelect): VehicleInventoryItem {
  return {
    id: vehicle.id,
    year: vehicle.year,
    make: vehicle.make,
    model: vehicle.model,
    price: vehicle.price,
    hp: vehicle.hp,
    drivetrain: vehicle.drivetrain as VehicleInventoryItem["drivetrain"],
    zeroToHundred: vehicle.zeroToHundredTenths / 10,
    mileage: vehicle.mileage,
    image: vehicle.imageUrl,
    tags: parseTags(vehicle.tagsJson),
    dossier: vehicle.dossier,
  };
}

function parseTags(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((tag): tag is string => typeof tag === "string") : [];
  } catch {
    return [];
  }
}
