import mysql from "mysql2/promise";
import { z } from "zod";

const enquiryInputSchema = z.object({
  name: z.string().trim().min(2, "Meno musí mať aspoň 2 znaky.").max(160),
  email: z.string().trim().email("Zadajte platný e-mail.").max(320),
  vehicle: z.string().trim().min(2, "Uveďte vozidlo alebo typ požiadavky.").max(240),
  message: z.string().trim().min(5, "Správa musí mať aspoň 5 znakov.").max(5000),
});

export type EnquiryInput = z.infer<typeof enquiryInputSchema>;
export type EnquiryRecord = EnquiryInput & {
  id: number;
  source: string;
  createdAt: string;
};

let pool: mysql.Pool | null = null;

function getPool() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not configured.");
  }

  if (!pool) {
    pool = mysql.createPool(process.env.DATABASE_URL);
  }

  return pool;
}

export function validateEnquiryInput(input: unknown): EnquiryInput {
  return enquiryInputSchema.parse(input);
}

export async function saveEnquiry(input: unknown): Promise<EnquiryRecord> {
  const enquiry = validateEnquiryInput(input);
  const db = getPool();

  const [result] = await db.execute<mysql.ResultSetHeader>(
    "INSERT INTO enquiries (name, email, vehicle, message, source) VALUES (?, ?, ?, ?, ?)",
    [enquiry.name, enquiry.email, enquiry.vehicle, enquiry.message, "contact-form"],
  );

  return {
    ...enquiry,
    id: result.insertId,
    source: "contact-form",
    createdAt: new Date().toISOString(),
  };
}

export async function listRecentEnquiries(limit = 20): Promise<EnquiryRecord[]> {
  const db = getPool();
  const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 100);

  const [rows] = await db.execute<mysql.RowDataPacket[]>(
    `SELECT id, name, email, vehicle, message, source, createdAt
     FROM enquiries
     ORDER BY createdAt DESC
     LIMIT ${safeLimit}`,
  );

  return rows.map((row) => ({
    id: Number(row.id),
    name: String(row.name),
    email: String(row.email),
    vehicle: String(row.vehicle),
    message: String(row.message),
    source: String(row.source),
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : new Date(row.createdAt).toISOString(),
  }));
}
