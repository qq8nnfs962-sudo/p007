import { describe, expect, it } from "vitest";
import { listRecentEnquiries, saveEnquiry, validateEnquiryInput } from "./enquiries";

describe("enquiry persistence", () => {
  it("validates required contact form fields", () => {
    expect(() => validateEnquiryInput({ name: "A", email: "bad", vehicle: "", message: "x" })).toThrow();
  });

  it("saves a user-generated contact form submission to the database", async () => {
    const marker = `Vitest persistence ${Date.now()}`;

    const saved = await saveEnquiry({
      name: "Test Klient",
      email: "test-klient@example.com",
      vehicle: "Aston Martin DB12",
      message: marker,
    });

    expect(saved.id).toBeGreaterThan(0);
    expect(saved.source).toBe("contact-form");
    expect(saved.message).toBe(marker);

    const recent = await listRecentEnquiries(10);
    expect(recent.some((enquiry) => enquiry.id === saved.id && enquiry.message === marker)).toBe(true);
  });
});
