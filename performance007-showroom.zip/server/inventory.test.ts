import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("inventory.list", () => {
  it("returns the seeded persistent showroom inventory", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    const vehicles = await caller.inventory.list();

    expect(vehicles.length).toBeGreaterThanOrEqual(4);
    expect(vehicles[0]).toMatchObject({
      id: "p007-db12-shadow",
      make: "Aston Martin",
      model: "DB12 Shadow Protocol",
      price: 137000,
      hp: 680,
      zeroToHundred: 3.6,
      tags: ["Karbónový balík", "Keramické brzdy", "Zberateľský stav"],
    });
  });
});
