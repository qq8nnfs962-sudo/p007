import "dotenv/config";
import express from "express";
import { createServer as createHttpServer } from "http";
import { createServer as createViteServer } from "vite";
import { registerApiRoutes } from "../apiRoutes";

async function startServer() {
  const app = express();
  const server = createHttpServer(app);

  app.use(express.json({ limit: "32kb" }));
  registerApiRoutes(app);

  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });

  app.use(vite.middlewares);

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch((error) => {
  console.error(error);
  process.exit(1);
});
