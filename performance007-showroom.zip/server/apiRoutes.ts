import type { Express } from "express";
import { ZodError } from "zod";
import { getCRMAnalytics } from "./crmAnalytics";
import { saveEnquiry } from "./enquiries";

export function registerApiRoutes(app: Express) {
  app.get("/api/crm/analytics", async (_req, res) => {
    try {
      const analytics = await getCRMAnalytics();
      res.json({ success: true, analytics });
    } catch (error) {
      console.error("[CRM] Failed to load analytics:", error);
      res.status(500).json({ success: false, error: "CRM analytiku sa nepodarilo načítať." });
    }
  });

  app.post("/api/enquiries", async (req, res) => {
    try {
      const enquiry = await saveEnquiry(req.body);
      res.status(201).json({ success: true, enquiry });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ success: false, error: error.issues[0]?.message ?? "Neplatná požiadavka." });
        return;
      }

      console.error("[Enquiries] Failed to save submission:", error);
      res.status(500).json({ success: false, error: "Požiadavku sa nepodarilo uložiť." });
    }
  });
}
