import { EnquiryRecord, listRecentEnquiries } from "./enquiries";

export type CRMLead = EnquiryRecord & {
  stage: "Nový lead" | "Kvalifikácia" | "Ponuka" | "Financovanie";
  estimatedValue: number;
  priority: "Vysoká" | "Stredná" | "Nízka";
  nextAction: string;
};

export type CRMAnalytics = {
  generatedAt: string;
  totalLeads: number;
  pipelineValue: number;
  averageDealValue: number;
  financingRequests: number;
  highPriorityLeads: number;
  sourceDistribution: Array<{ source: string; count: number }>;
  stageDistribution: Array<{ stage: CRMLead["stage"]; count: number; value: number }>;
  recentLeads: CRMLead[];
};

const stageOrder: CRMLead["stage"][] = ["Nový lead", "Kvalifikácia", "Ponuka", "Financovanie"];

export function leadFromEnquiry(enquiry: EnquiryRecord): CRMLead {
  const combined = `${enquiry.vehicle} ${enquiry.message}`.toLowerCase();
  const estimatedValue = estimateDealValue(combined);
  const stage = inferStage(combined);
  const priority = estimatedValue >= 150000 || combined.includes("urgent") || combined.includes("rýchlo") ? "Vysoká" : estimatedValue >= 90000 ? "Stredná" : "Nízka";

  return {
    ...enquiry,
    stage,
    estimatedValue,
    priority,
    nextAction: stage === "Financovanie" ? "Pripraviť možnosti financovania" : stage === "Ponuka" ? "Odoslať kurátorovaný návrh vozidiel" : "Kontaktovať klienta a kvalifikovať požiadavku",
  };
}

export function calculateCRMAnalytics(enquiries: EnquiryRecord[]): CRMAnalytics {
  const recentLeads = enquiries.map(leadFromEnquiry);
  const pipelineValue = recentLeads.reduce((sum, lead) => sum + lead.estimatedValue, 0);
  const sourceCounts = new Map<string, number>();
  const stageMetrics = new Map<CRMLead["stage"], { count: number; value: number }>();

  for (const lead of recentLeads) {
    sourceCounts.set(lead.source, (sourceCounts.get(lead.source) ?? 0) + 1);
    const current = stageMetrics.get(lead.stage) ?? { count: 0, value: 0 };
    stageMetrics.set(lead.stage, { count: current.count + 1, value: current.value + lead.estimatedValue });
  }

  return {
    generatedAt: new Date().toISOString(),
    totalLeads: recentLeads.length,
    pipelineValue,
    averageDealValue: recentLeads.length ? Math.round(pipelineValue / recentLeads.length) : 0,
    financingRequests: recentLeads.filter((lead) => lead.stage === "Financovanie").length,
    highPriorityLeads: recentLeads.filter((lead) => lead.priority === "Vysoká").length,
    sourceDistribution: Array.from(sourceCounts, ([source, count]) => ({ source, count })),
    stageDistribution: stageOrder.map((stage) => {
      const metric = stageMetrics.get(stage) ?? { count: 0, value: 0 };
      return { stage, ...metric };
    }),
    recentLeads,
  };
}

export async function getCRMAnalytics(): Promise<CRMAnalytics> {
  const enquiries = await listRecentEnquiries(100);
  return calculateCRMAnalytics(enquiries);
}

function inferStage(text: string): CRMLead["stage"] {
  if (text.includes("financ") || text.includes("splát") || text.includes("leasing")) return "Financovanie";
  if (text.includes("ponuk") || text.includes("cena") || text.includes("rozpočet")) return "Ponuka";
  if (text.includes("dovoz") || text.includes("výkup") || text.includes("objednáv")) return "Kvalifikácia";
  return "Nový lead";
}

function estimateDealValue(text: string): number {
  if (text.includes("porsche") || text.includes("911") || text.includes("turbo")) return 242000;
  if (text.includes("mercedes") || text.includes("amg") || text.includes("gt 63")) return 219000;
  if (text.includes("bmw") || text.includes("m4")) return 158000;
  if (text.includes("aston") || text.includes("db12")) return 137000;
  if (text.includes("financ")) return 77000;
  return 95000;
}
