import { describe, expect, it } from "vitest";
import { calculateCRMAnalytics, leadFromEnquiry } from "./crmAnalytics";
import type { EnquiryRecord } from "./enquiries";

const baseEnquiry: EnquiryRecord = {
  id: 1,
  name: "CRM Klient",
  email: "crm@example.com",
  vehicle: "Porsche 911 Turbo financovanie",
  message: "Prosím pripraviť možnosti financovania a ponuku.",
  source: "contact-form",
  createdAt: "2026-05-05T20:00:00.000Z",
};

describe("CRM analytics", () => {
  it("converts persisted enquiries into deterministic CRM leads", () => {
    const lead = leadFromEnquiry(baseEnquiry);

    expect(lead.stage).toBe("Financovanie");
    expect(lead.estimatedValue).toBe(242000);
    expect(lead.priority).toBe("Vysoká");
    expect(lead.nextAction).toBe("Pripraviť možnosti financovania");
  });

  it("calculates sales dashboard summary metrics from CRM enquiry data", () => {
    const analytics = calculateCRMAnalytics([
      baseEnquiry,
      {
        ...baseEnquiry,
        id: 2,
        vehicle: "BMW M4 dovoz",
        message: "Zaujíma ma dovoz vozidla na objednávku.",
      },
    ]);

    expect(analytics.totalLeads).toBe(2);
    expect(analytics.pipelineValue).toBe(400000);
    expect(analytics.averageDealValue).toBe(200000);
    expect(analytics.financingRequests).toBe(1);
    expect(analytics.sourceDistribution).toEqual([{ source: "contact-form", count: 2 }]);
    expect(analytics.stageDistribution.find((item) => item.stage === "Financovanie")?.count).toBe(1);
    expect(analytics.stageDistribution.find((item) => item.stage === "Kvalifikácia")?.count).toBe(1);
  });
});
