import express from "express";
import { createServer } from "http";
import { AddressInfo } from "net";
import { afterEach, describe, expect, it } from "vitest";
import { registerApiRoutes } from "./apiRoutes";

describe("CRM analytics API route", () => {
  let server: ReturnType<typeof createServer> | null = null;

  afterEach(async () => {
    if (!server) return;
    await new Promise<void>((resolve, reject) => server?.close((error) => (error ? reject(error) : resolve())));
    server = null;
  });

  async function startApi() {
    const app = express();
    app.use(express.json());
    registerApiRoutes(app);
    server = createServer(app);
    await new Promise<void>((resolve) => server?.listen(0, "127.0.0.1", resolve));
    const address = server.address() as AddressInfo;
    return `http://127.0.0.1:${address.port}`;
  }

  it("returns CRM analytics generated from persisted enquiries", async () => {
    const baseUrl = await startApi();
    const response = await fetch(`${baseUrl}/api/crm/analytics`);
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(payload.success).toBe(true);
    expect(payload.analytics).toMatchObject({
      totalLeads: expect.any(Number),
      pipelineValue: expect.any(Number),
      averageDealValue: expect.any(Number),
      sourceDistribution: expect.any(Array),
      stageDistribution: expect.any(Array),
      recentLeads: expect.any(Array),
    });
  });
});
