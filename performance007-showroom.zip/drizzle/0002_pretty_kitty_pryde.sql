CREATE TABLE `enquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`vehicle` varchar(240) NOT NULL,
	`message` text NOT NULL,
	`source` varchar(80) NOT NULL DEFAULT 'contact-form',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `enquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `users`;--> statement-breakpoint
DROP TABLE `vehicles`;