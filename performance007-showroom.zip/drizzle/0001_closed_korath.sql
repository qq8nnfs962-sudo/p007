CREATE TABLE `vehicles` (
	`id` varchar(64) NOT NULL,
	`year` int NOT NULL,
	`make` varchar(120) NOT NULL,
	`model` varchar(160) NOT NULL,
	`price` int NOT NULL,
	`hp` int NOT NULL,
	`drivetrain` varchar(32) NOT NULL,
	`zeroToHundredTenths` int NOT NULL,
	`mileage` int NOT NULL,
	`imageUrl` text NOT NULL,
	`tagsJson` text NOT NULL,
	`dossier` text NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vehicles_id` PRIMARY KEY(`id`)
);
