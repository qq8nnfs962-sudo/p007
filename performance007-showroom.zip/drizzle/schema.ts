import { int, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const enquiries = mysqlTable("enquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  vehicle: varchar("vehicle", { length: 240 }).notNull(),
  message: text("message").notNull(),
  source: varchar("source", { length: 80 }).default("contact-form").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Enquiry = typeof enquiries.$inferSelect;
export type InsertEnquiry = typeof enquiries.$inferInsert;
